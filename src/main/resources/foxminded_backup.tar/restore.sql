--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.8
-- Dumped by pg_dump version 10.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.students DROP CONSTRAINT students_group_id_fkey;
ALTER TABLE ONLY public.courses_students DROP CONSTRAINT courses_students_student_id;
ALTER TABLE ONLY public.courses_students DROP CONSTRAINT courses_students_course_id;
ALTER TABLE ONLY public.students DROP CONSTRAINT students_pkey;
ALTER TABLE ONLY public.groups DROP CONSTRAINT groups_pkey;
ALTER TABLE ONLY public.groups DROP CONSTRAINT groups_name_key;
ALTER TABLE ONLY public.courses_students DROP CONSTRAINT courses_students_pkey;
ALTER TABLE ONLY public.courses DROP CONSTRAINT courses_pkey;
ALTER TABLE ONLY public.courses DROP CONSTRAINT courses_name_key;
DROP TABLE public.students;
DROP TABLE public.groups;
DROP TABLE public.courses_students;
DROP TABLE public.courses;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courses (
    course_id character varying(50) NOT NULL,
    name character varying(150) NOT NULL,
    description character varying(500)
);


ALTER TABLE public.courses OWNER TO postgres;

--
-- Name: courses_students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courses_students (
    course_id character varying(50) NOT NULL,
    student_id character varying(50) NOT NULL
);


ALTER TABLE public.courses_students OWNER TO postgres;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    group_id character varying(50) NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    student_id character varying(50) NOT NULL,
    group_id character varying(50) NOT NULL,
    first_name character varying(150),
    last_name character varying(150)
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courses (course_id, name, description) FROM stdin;
\.
COPY public.courses (course_id, name, description) FROM '$$PATH$$/2819.dat';

--
-- Data for Name: courses_students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courses_students (course_id, student_id) FROM stdin;
\.
COPY public.courses_students (course_id, student_id) FROM '$$PATH$$/2820.dat';

--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.groups (group_id, name) FROM stdin;
\.
COPY public.groups (group_id, name) FROM '$$PATH$$/2817.dat';

--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (student_id, group_id, first_name, last_name) FROM stdin;
\.
COPY public.students (student_id, group_id, first_name, last_name) FROM '$$PATH$$/2818.dat';

--
-- Name: courses courses_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_name_key UNIQUE (name);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (course_id);


--
-- Name: courses_students courses_students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses_students
    ADD CONSTRAINT courses_students_pkey PRIMARY KEY (course_id, student_id);


--
-- Name: groups groups_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_name_key UNIQUE (name);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (group_id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (student_id);


--
-- Name: courses_students courses_students_course_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses_students
    ADD CONSTRAINT courses_students_course_id FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: courses_students courses_students_student_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses_students
    ADD CONSTRAINT courses_students_student_id FOREIGN KEY (student_id) REFERENCES public.students(student_id);


--
-- Name: students students_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(group_id);


--
-- PostgreSQL database dump complete
--

